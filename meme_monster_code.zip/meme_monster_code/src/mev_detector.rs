use anyhow::{Context, Result};
use solana_client::{rpc_client::RpcClient, rpc_config::RpcSimulateTransactionConfig, rpc_config::RpcSimulateTransactionAccountsConfig};
use solana_sdk::{account::Account, pubkey::Pubkey, transaction::VersionedTransaction};
use raydium_amm_swap::states::AmmInfo;
use solana_sdk::transaction::UiAccountEncoding;
use solana_trading_sdk::{dex::{Raydium, Orca}, price::PriceFetcher};

pub struct ArbPath {
    pub buy_dex: String,
    pub sell_dex: String,
    pub profit_est: f64,
}

pub async fn detect_arb(client: &RpcClient, mint: Pubkey) -> Result<Option<ArbPath>> {
    let fetcher = PriceFetcher::new(client);
    let price_raydium = fetcher.get_price(&Raydium, mint).await?;
    let price_orca = fetcher.get_price(&Orca, mint).await?;

    let diff = (price_raydium - price_orca).abs();
    if diff > 0.01 {
        let profit_est = diff * 1.0;
        return Ok(Some(ArbPath {
            buy_dex: if price_orca < price_raydium { "Orca".to_string() } else { "Raydium".to_string() },
            sell_dex: if price_orca > price_raydium { "Orca".to_string() } else { "Raydium".to_string() },
            profit_est,
        }));
    }
    Ok(None)
}

pub async fn detect_sandwich(client: &RpcClient, tx: &VersionedTransaction) -> Result<Option<Opportunity>> {
    let pool_pubkey = /* extract from tx */;
    
    let pre_pool_acc = client.get_account(&pool_pubkey)
        .context("Failed to fetch pre pool account")?;
    let pre_pool = AmmInfo::try_from_slice(&pre_pool_acc.data)
        .context("Failed to parse pre pool")?;
    let pre_price = pre_pool.token_b_reserve as f64 / pre_pool.token_a_reserve as f64;

    let config = RpcSimulateTransactionConfig {
        replace_recent_blockhash: true,
        accounts: Some(RpcSimulateTransactionAccountsConfig {
            encoding: Some(UiAccountEncoding::Base64),
            addresses: vec![pool_pubkey.to_string()],
        }),
        ..Default::default()
    };
    let sim_result = client.simulate_transaction_with_config(tx, config)
        .context("Simulation failed")?;

    if let Some(err) = sim_result.err {
        anyhow::bail!("Sim failed: {:?}", err);
    }

    let post_accounts = sim_result.accounts.ok_or(anyhow::anyhow!("No accounts in sim result"))?;
    let post_pool_acc: Account = post_accounts.into_iter().next().ok_or(anyhow::anyhow!("No pool in sim accounts"))?
        .decode().context("Failed to decode post pool")?;
    let post_pool = AmmInfo::try_from_slice(&post_pool_acc.data)
        .context("Failed to parse post pool")?;
    let post_price = post_pool.token_b_reserve as f64 / post_pool.token_a_reserve as f64;

    let edge = (post_price - pre_price) / pre_price;
    if edge > 0.05 {
        return Ok(Some(Opportunity { mint: /* from tx */, liq_sol: /* */, edge }));
    }

    if let Some(logs) = sim_result.logs {
        for log in logs {
            if log.contains("Swap failed") {
                anyhow::bail!("Swap error in logs: {}", log);
            }
        }
    }

    Ok(None)
}

pub fn calculate_entropy(data: &[u8]) -> f64 {
    if data.is_empty() { return 0.0; }
    let mut freq = [0u32; 256];
    for &byte in data { freq[byte as usize] += 1; }
    let len = data.len() as f64;
    freq.iter().filter(|&&f| f > 0).fold(0.0, |ent, &f| {
        let p = f as f64 / len;
        ent - p * p.log2()
    })
}