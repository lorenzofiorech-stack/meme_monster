use solana_client::pubsub_client::PubsubClient;
use solana_sdk::signature::Signature;
use futures_util::stream::StreamExt;
use std::error::Error;
use anyhow::{Context, Result};
use solana_client::rpc_client::RpcClient;
use solana_sdk::{commitment_config::CommitmentConfig, pubkey::Pubkey, transaction::VersionedTransaction};
use solana_sdk::borsh0_10::try_from_slice_unchecked;
use spl_token::instruction::TokenInstruction;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::Mutex;
use tracing_subscriber;

#[derive(BorshDeserialize, Debug)]
struct RaydiumSwapInstruction {
    amount_in: u64,
    min_amount_out: u64,
}

pub struct Opportunity {
    pub mint: Pubkey,
    pub liq_sol: f64,
    pub edge: f64,
}

async fn process_transaction(sig: Signature) -> Result<()> {
    let rpc_url = "https://api.devnet.solana.com";
    let client = RpcClient::new_with_commitment(rpc_url.to_string(), CommitmentConfig::processed());

    let tx_opt = client.get_transaction(&sig, solana_sdk::transaction::UiTransactionEncoding::Base64)
        .context("Failed to fetch transaction")?;
    
    if let Some(tx_meta) = tx_opt.transaction {
        if let VersionedTransaction::Legacy(tx) = tx_meta.transaction {
            for ix in tx.message.instructions.iter() {
                let program_id = tx.message.account_keys[ix.program_id_index as usize];

                if program_id == Pubkey::from_str("675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8")? {
                    if !ix.data.is_empty() && ix.data[0] == 9 {
                        let swap_ix = RaydiumSwapInstruction::try_from_slice(&ix.data[1..])
                            .context("Failed to deserialize Raydium swap instruction")?;
                        
                        let liq_sol = swap_ix.amount_in as f64 / 1_000_000_000.0;
                        let slippage = swap_ix.min_amount_out as f64 / swap_ix.amount_in as f64;

                        let token_a_mint = tx.message.account_keys.get(ix.accounts.get(4).copied().unwrap_or(0) as usize)
                            .cloned().unwrap_or_default();
                        let token_b_mint = tx.message.account_keys.get(ix.accounts.get(5).copied().unwrap_or(0) as usize)
                            .cloned().unwrap_or_default();

                        println!("Raydium swap parsed: input_mint {:?}, output_mint {:?}, liq_sol {:.3}, slippage {:.2}%",
                                 token_a_mint, token_b_mint, liq_sol, slippage * 100.0);

                        if let Some(opp) = mev_detector::detect_sandwich(&client, &tx).await? {
                            println!("Sandwich opp found: {:?}", opp);
                        }
                    }
                }
            }
        }
    }

    Ok(())
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt::init();

    let wss_url = "wss://api.devnet.solana.com/".to_string();
    let known_ids = Arc::new(Mutex::new(HashMap::<Pubkey, u64>::new()));
    let learning_mode = std::env::var("LEARNING_MODE").unwrap_or_default() == "true";

    loop {
        match PubsubClient::signature_subscribe(&wss_url, None) {
            Ok((mut stream, _sub_id)) => {
                while let Some(result) = stream.next().await {
                    if let Ok(sig_result) = result {
                        if let Some(sig) = sig_result.signature {
                            if let Err(e) = process_transaction(sig).await {
                                tracing::error!("Tx process error: {:?}", e);
                            }
                        }
                    }
                }
            }
            Err(e) => {
                tracing::error!("WS error: {:?}. Reconnecting...", e);
                tokio::time::sleep(tokio::time::Duration::from_secs(1)).await;
            }
        }
    }
}